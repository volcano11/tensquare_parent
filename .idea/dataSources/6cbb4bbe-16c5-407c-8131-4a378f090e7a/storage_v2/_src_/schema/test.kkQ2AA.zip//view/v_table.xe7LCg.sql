create view v_table as
  select
    `test`.`score`.`s_id`                                   AS `s_id`,
    (count(`test`.`score`.`c_id`) < (select count(`test`.`course`.`c_id`)
                                     from `test`.`course`)) AS `flag`
  from `test`.`score`
  group by `test`.`score`.`s_id`;

